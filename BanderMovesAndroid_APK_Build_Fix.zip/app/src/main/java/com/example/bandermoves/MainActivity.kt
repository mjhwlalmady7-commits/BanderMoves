package com.example.bandermoves

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

private val background = Color(0xFF101116)
private val panel = Color(0xFF20232B)
private val accent = Color(0xFFFF1828)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = accent,
                    background = background,
                    surface = panel
                )
            ) {
                BanderMovesApp()
            }
        }
    }
}

@Composable
private fun BanderMovesApp() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Movie?>(null) }
    var playing by remember { mutableStateOf<Movie?>(null) }
    var category by remember { mutableStateOf("الكل") }

    Surface(Modifier.fillMaxSize(), color = background) {
        when {
            playing != null -> {
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    TextButton(onClick = { playing = null }) { Text("← رجوع") }
                    Text(playing!!.title, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(16.dp))
                    VideoPlayer(url = playing!!.videoUrl)
                }
            }
            selected != null -> {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    TextButton(onClick = { selected = null }) { Text("← رجوع إلى المكتبة") }
                    Text(selected!!.title, style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("${selected!!.year} • ${selected!!.category}", color = accent)
                    Spacer(Modifier.height(16.dp))
                    Text(selected!!.description, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { playing = selected },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("▶ مشاهدة") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { downloadVideo(context, selected!!) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("⬇ تنزيل للمشاهدة دون إنترنت") }
                    Spacer(Modifier.height(12.dp))
                    Text("التنزيل متاح للروابط المباشرة التي تسمح بذلك.", color = Color.LightGray)
                }
            }
            else -> {
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(22.dp))
                    Text("Bander Moves", style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold, color = accent)
                    Text("مكتبتك للأفلام والمسلسلات", color = Color.LightGray)
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("ابحث عن فيلم أو مسلسل") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("الكل", "مغامرات", "وثائقي", "دراما").forEach { item ->
                            FilterChip(
                                selected = category == item,
                                onClick = { category = item },
                                label = { Text(item) }
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("اكتشف المحتوى", style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold)
                    LazyColumn(
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val filtered = sampleMovies.filter {
                            (category == "الكل" || it.category == category) &&
                            it.title.contains(query, ignoreCase = true)
                        }
                        items(filtered, key = { it.id }) { movie ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { selected = movie },
                                colors = CardDefaults.cardColors(containerColor = panel)
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(color = Color(0xFF343946), shape = MaterialTheme.shapes.large) {
                                        Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                                            Text("▶", color = accent,
                                                style = MaterialTheme.typography.headlineMedium)
                                        }
                                    }
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(movie.title, fontWeight = FontWeight.Bold)
                                        Text("${movie.year} • ${movie.category}",
                                            color = Color.LightGray)
                                        Text("اضغط لعرض التفاصيل", color = accent,
                                            style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun downloadVideo(context: Context, movie: Movie) {
    try {
        val request = DownloadManager.Request(Uri.parse(movie.videoUrl))
            .setTitle(movie.title)
            .setDescription("تنزيل للمشاهدة دون إنترنت")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(
                context, Environment.DIRECTORY_MOVIES, "BanderMoves_${movie.id}.mp4"
            )
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(context, "بدأ التنزيل. تحقق من إشعار الهاتف.", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "تعذر بدء التنزيل: تحقق من رابط الفيديو والإنترنت.", Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun VideoPlayer(url: String) {
    val context = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(240.dp)
    )
}
