package com.example.bandermoves

data class Movie(
    val id: Int,
    val title: String,
    val year: Int,
    val category: String,
    val description: String,
    val videoUrl: String
)

// ضع هنا روابط ملفات فيديو مباشرة تملك حق عرضها وتنزيلها.
val sampleMovies = listOf(
    Movie(1, "رحلة إلى المجهول", 2024, "مغامرات",
        "فيلم تجريبي لتوضيح شكل صفحة التفاصيل ومشغل الفيديو.",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
    Movie(2, "كوكبنا الجميل", 2023, "وثائقي",
        "عنوان تجريبي. استبدل رابط الفيديو بمحتوى مرخص.",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
    Movie(3, "حكايات المدينة", 2025, "دراما",
        "يمكنك لاحقًا إضافة مواسم وحلقات للمسلسلات.",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4")
)
